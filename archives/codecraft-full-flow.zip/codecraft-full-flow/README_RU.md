# CodeCraft API: переносимый комплект полного флоу

`codecraft.py` регистрирует аккаунт по email, подтверждает его через Gmail, входит и создаёт одноразовый API-ключ. `codecraft_google.py` использует отдельный аккаунт Google OAuth, одноразовый ключ, проверку модели и запуск агента. `onemin.py` включён **только** как общая импортируемая библиотека для OAuth/прокси: для CodeCraft его команды запускать не нужно. Внутри офлайн-тесты и `requirements-oauth.txt`.

**В архиве нет** `.secrets/`, ключей, cookies, паролей, email-адреса аккаунта и значений прокси. Это код для воспроизведения, а не готовый вход в старый аккаунт. Если приватные файлы утеряны, перед новой регистрацией или созданием ключа сначала проверьте действующий аккаунт и dashboard. Переносите существующее приватное состояние только через доверенный менеджер секретов; не помещайте его обратно в архив.

## Регистрация и вход по email

POSIX/WSL и Python 3.10+, внешние Python-пакеты для этого пути не нужны. Задайте через приватное окружение/менеджер секретов `PROXY` (HTTP CONNECT-прокси с портом), `GMAILLOG` (email регистрации), а если нужен код подтверждения по почте — `APPASS` (пароль приложения Gmail). Имя задаётся `--name` или `CODECRAFT_NAME`.

```sh
python3 codecraft.py ensure --name 'Ваше имя'  # регистрация, подтверждение, один ключ
python3 codecraft.py status                   # офлайн: есть ли сохранённый ключ
python3 codecraft.py login                    # вход с сохранённым паролем
python3 codecraft.py run -- <команда-агента>
```

Сгенерированный пароль сохраняется **до регистрации**, а API-ключ при выдаче в `.secrets/codecraft.json` (каталог 0700, файл 0600). `CODECRAFT_CREDENTIALS_FILE` меняет приватный путь. Gmail-подтверждение ожидает код или ссылку до 3 часов (настройка `CODECRAFT_VERIFY_TIMEOUT`, максимум 86400 секунд). Новая CAPTCHA/проверка останавливает поток; обхода нет. Неоднозначную выдачу ключа `ensure` автоматически не повторяет. `run` передаёт агенту ключ и OpenAI-совместимый `https://codecraftapi.com/v1` с прокси; сам агент должен соблюдать его. В исходной среде **этот маршрут** не сохранил ключ: ожидалось подтверждение почты.

## Google OAuth (отдельный аккаунт)

Используйте `NEWPROXY` (не `PROXY`) и приватные `CODECRAFT_GOOGLE_EMAIL` и `CODECRAFT_GOOGLE_PASSWORD` при новом входе; не вводите пароль в команды. OAuth проверяет ровно `openid`, `email`, `profile`; дополнительная проверка Google останавливает поток. Только при разрешении пользователя/организации применяйте `--accept-workspace-notice` для входа или создания ключа.

```sh
uv venv --python python3 .venv
uv pip install --python .venv/bin/python -r requirements-oauth.txt
.venv/bin/python -m playwright install firefox
.venv/bin/python codecraft_google.py login
.venv/bin/python codecraft_google.py ensure  # восстановить состояние/создать не более одного ключа
.venv/bin/python codecraft_google.py verify  # GET /v1/models через NEWPROXY
.venv/bin/python codecraft_google.py status  # локально и без сети
.venv/bin/python codecraft_google.py run -- <команда-агента>
```

Ключ и email сохраняются в `.secrets/codecraft-google.json`, первая сторона сессии — в `.secrets/codecraft-google-session.json` (приватные права). Google-пароль и Google cookies не сохраняются. `CODECRAFT_GOOGLE_CREDENTIALS_FILE` может изменить путь ключа (сессия рядом), исходный email-аккаунт не затрагивается. Если создание одноразового ключа могло пройти, но результат потерян, новый ключ автоматически не создаётся. В исходной среде **Google OAuth маршрут** получил ключ и ранее прошёл проверку `/v1/models`; пустая копия ZIP не содержит этого ключа.

## Офлайн-проверка

```sh
python3 -m unittest discover -s tests -q
```

Реальные сетевые запросы требуют соответствующего `PROXY` либо `NEWPROXY`. На Windows запускайте эти POSIX-скрипты в WSL. Контрольные суммы всех файлов архива есть в `MANIFEST.sha256`; без разрешения не распространяйте архив исходников третьим лицам.
