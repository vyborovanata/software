# 1min.ai → Claude / ZCode: переносимый комплект

Содержимое: `onemin.py` (Google OAuth, восстановление/создание ключа и API-чаты), `onemin_rewards.py` (анкета и ежедневные визиты), `onemin_adapter.py` (локальный мост OpenAI API для ZCode), общие функции хранения из `codecraft.py`, зависимости и офлайн-тесты. Для 1min.ai запускать команды `codecraft.py` не требуется.

**Это код, а не копия аккаунта.** Нет `.secrets/`, API-ключей, cookies, паролей, токена адаптера или настроек прокси. Для продолжения работы с существующим аккаунтом восстановите приватные файлы только через доверенный менеджер секретов. Пустая распаковка может показывать `not submitted` и `API key not saved`, хотя на сайте заявка и ключ уже существуют: не отправляйте повторные заявки и не создавайте повторный ключ по одному лишь локальному статусу. Пересылайте архив только получателям с доступом к исходникам.

## Подготовка и вход

Нужны POSIX или WSL, Python 3.10+, Firefox через Playwright и HTTP-прокси в переменной `PROXY`. На новой машине:

```sh
uv venv --python python3 .venv
uv pip install --python .venv/bin/python -r requirements-oauth.txt
.venv/bin/python -m playwright install firefox
python3 -m unittest discover -s tests -q  # без подключения к сервису
```

Поместите `PROXY`, `ONEMIN_EMAIL` и `ONEMIN_PASSWORD` в приватное окружение или менеджер секретов **только для необходимого входа**; не добавляйте их в архив или командную строку. Первый вход через Google может создать аккаунт на сайте; регистрация по email/password этим CLI не реализована. Проверяются только OAuth scopes `openid`, `email`, `profile`; дополнительные проверки или неожиданный экран останавливают процесс. `--accept-workspace-notice` используйте лишь если уполномочены принять уведомление.

```sh
.venv/bin/python onemin.py login   # первый вход или продление сессии через PROXY
.venv/bin/python onemin.py ensure  # восстановить существующий ключ или создать один
.venv/bin/python onemin.py status  # локальный статус без вывода ключа
printf 'Reply exactly OK.\n' | .venv/bin/python onemin.py chat --model us.anthropic.claude-opus-5
```

`chat` отправляет запрос и расходует кредиты. После неоднозначной выдачи ключа `ensure` не повторяет создание: проверьте панель сайта. Ключ и первая сторона сессии хранятся в `.secrets/onemin.json` и `.secrets/onemin-session.json` (приватные права); Google-пароль и Google cookies не сохраняются. `ONEMIN_CREDENTIALS_FILE` может переопределить путь ключа (сессия рядом). Внешний Chat API 1min.ai не является OpenAI-совместимым.

## Ранний доступ к AI Agent и ежедневная страница кредитов

Для **исходного аккаунта заявка уже отправлена**: на 26.09.2026 сервер показывал `submitted=true`, `teamRewarded=false`. Награда 1 000 000 — **кредиты, не токены**, её одобряет администрация. Повторную заявку на этот аккаунт не отправляйте. Только для другого аккаунта, где сервер подтверждает отсутствие заявки, можно просмотреть черновик всех пяти ответов (без отправки):

```sh
.venv/bin/python onemin_rewards.py survey --role 'Software Engineer / Developer' \
  --industry 'SaaS / Technology' --organization 'Solo entrepreneur' \
  --use-case 'Software Development & Coding' --frequency 'Daily'
# После проверки правдивости ответов и задачи повторите команду с --submit ОДИН раз.
# --task-file принимает UTF-8 файл 0600 в приватном каталоге 0700.
.venv/bin/python onemin_rewards.py status  # только офлайн-статус
```

Ежедневный визит к предложению 15 000 кредитов (не доказательство начисления):

```sh
.venv/bin/python onemin_rewards.py daily  # не чаще одного раза за сутки по фиксированному PST
.venv/bin/python onemin_rewards.py watch  # после 08:15 UTC, только пока процесс запущен
```

`watch` требует постоянно работающий хост, приватный `PROXY` и внешний супервизор; здесь cron/systemd не настроен. Ошибку в этот день скрипт автоматически не повторяет. Если срок OAuth-сессии истечёт, нужен разрешённый новый вход. В исходной среде визит за 26.09.2026 PST был подтверждён, но начисление дополнительных 15 000 кредитов отдельно не доказано. Архив не содержит прежний маркер визита: перед `daily` на новой машине проверьте сайт вручную.

## Локальный адаптер для ZCode

Запустите на **той же машине, где работает ZCode**, с приватным ключом 1min.ai и `PROXY`:

```sh
.venv/bin/python onemin_adapter.py serve  # слушает только 127.0.0.1:8765
.venv/bin/python onemin_adapter.py token  # получите ключ только для ZCode локально
```

В ZCode: `Manage Models → Model Settings → Add Provider → OpenAI protocol`, Base URL `http://127.0.0.1:8765/v1`, API Key — вывод команды `token` (**не** настоящий ключ 1min.ai), Model ID `us.anthropic.claude-opus-5`. Не выставляйте локальный порт в интернет и исключите `127.0.0.1` из прокси ZCode. Адаптер создаёт отдельный `.secrets/onemin-adapter-token` (0600), запросы к 1min.ai расходуют кредиты. Tool calling переводится best-effort, полноценная работа десктопного ZCode здесь не подтверждена. Для Windows нужен WSL с доступом ZCode к localhost.

Контрольные суммы файлов архива перечислены в `MANIFEST.sha256`.
